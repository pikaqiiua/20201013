

inputFile="singleGeneClinical.txt"                                        
setwd("C:\\Users\\lexb4\\Desktop\\singleGene\\15.logistic")                
rt=read.table(inputFile,sep="\t",header=T,check.names=F)                  
clinical="stage"
gene="VCAN"
data=rt[,c(clinical,gene)]
colnames(data)=c("clinical","gene")
data=cbind(data,y=ifelse(rt[,gene]>median(rt[,gene]),1,0))
logit=glm(y~clinical,family=binomial(link='logit'),data=data)
summ=summary(logit)
conf=confint(logit,level = 0.95)
cbind(OR=exp(summ$coefficients[2,"Estimate"]),
      OR.95L=exp(conf[2,1]),
      OR.95H=exp(conf[2,2]),
      p=summ$coefficients[2,"Pr(>|z|)"])

