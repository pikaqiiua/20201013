

#install.packages('survival')
#install.packages("survminer")

library(survival)
library(survminer)
setwd("D:\\Liver hepatocellular carcinoma\\singleGene\\18.multiCox-DFS")
rt=read.table("2.txt",header=T,sep="\t",check.names=F,row.names=1)
#rt[,"YTHDF2"]=log2(rt[,"YTHDF2"]+1)

multiCox=coxph(Surv(futime, fustat) ~ ., data = rt)
multiCoxSum=summary(multiCox)

outTab=data.frame()
outTab=cbind(
             HR=multiCoxSum$conf.int[,"exp(coef)"],
             HR.95L=multiCoxSum$conf.int[,"lower .95"],
             HR.95H=multiCoxSum$conf.int[,"upper .95"],
             pvalue=multiCoxSum$coefficients[,"Pr(>|z|)"])
outTab=cbind(id=row.names(outTab),outTab)
write.table(outTab,file="multiCox.xls",sep="\t",row.names=F,quote=F)

pdf(file="forest.pdf",
       width = 7,            
       height = 6,           
       )
ggforest(multiCox,
         main = "Hazard ratio",
         cpositions = c(0.02,0.22, 0.4), 
         fontsize = 0.7, 
         refLabel = "reference", 
         noDigits = 2)
dev.off()

