

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma", version = "3.8")

library("limma")

setwd("C:\\Users\\DJ\\Desktop\\Liver hepatocellular carcinoma\\singleGene\\05.uniq")              
gene="YTHDF2"                                                           
normalNum=50                                                         
tumorNum=374                                                         

rt=read.table("symbol.txt",sep="\t",header=T,check.names=F)         
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)


uniq=rbind(ID=colnames(data),data)
write.table(uniq,file="uniq.symbol.txt",sep="\t",quote=F,col.names=F)        


Type=c(rep("Normal",normalNum),rep("Tumor",tumorNum))
single=cbind(ID=colnames(data),expression=data[gene,],Type)
colnames(single)=c("ID",gene,"Type")
write.table(single,file="singleGene.txt",sep="\t",quote=F,row.names=F)

