

#install.packages("survival")

setwd("C:\\Users\\DJ\\Desktop\\Liver hepatocellular carcinoma\\singleGene\\12.survival")    #����Ŀ¼�����޸ģ�
gene="YTHDF2"

library(survival)
rt=read.table("survival.txt",header=T,sep="\t",check.names=F)
rt$futime=rt$futime/365                                        #�������Ϊ��λ������30������Ϊ��λ������365

a=rt[,gene]<=median(rt[,gene])
diff=survdiff(Surv(futime, fustat) ~a,data = rt)
pValue=1-pchisq(diff$chisq,df=1)
if(pValue<0.001){
     pValue=signif(pValue,4)
     pValue=format(pValue, scientific = TRUE)
}else{
     pValue=round(pValue,3)
}

fit <- survfit(Surv(futime, fustat) ~ a, data = rt)

pdf(file="survival.pdf",
    width=6,
    height=6)
plot(fit, 
     lwd=2,
     col=c("red","blue"),
     xlab="Time (year)",
     xlim=c(0,5),        
     mark.time=T,
     ylab="Survival rate",
     main=paste(gene,"(p=", pValue ,")",sep="") )
legend("topright", 
     c("High expression","Low expression"), 
     lwd=2, 
     col=c("red","blue"))
dev.off()
summary(fit)

