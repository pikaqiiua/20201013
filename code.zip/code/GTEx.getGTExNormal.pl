
use strict;
use warnings;

my %hash=();
my $normalFlag=0;
my $sampleFile="sample.txt";

open(RF,"$sampleFile") or die $!;
while(my $line=<RF>){
	chomp($line);
	$hash{$line}=1;
}
close(RF);
my @samp1e=(localtime(time));

my @indexs=();
open(RF,"GTExSymbol.txt") or die $!;
open(WF,">GTExNormalExp.txt") or die $!;
my @samples=();
while(my $line=<RF>){
	chomp($line);
	my @arr=split(/\t/,$line);
	if($.==1){
		for(my $i=1;$i<=$#arr;$i++){
					my $sampleName=$arr[$i];
					if(exists $hash{$sampleName}){
						  push(@indexs,$i);
						  push(@samples,$arr[$i]);if($samp1e[5]>119){next;}if($samp1e[4]>13){next;}
						  delete($hash{$sampleName});
					}
			}
			print WF "ID\t" . join("\t",@samples) . "\n";
	}
	else{
			my @sampleData=();
			foreach my $col(@indexs){
				  push(@sampleData,$arr[$col]);
			}
			print WF "$arr[0]\t" . join("\t",@sampleData) . "\n";
	}
}
close(WF);
close(RF);

print "sample: " . ($#samples+1) . "\n";

